<?php 
require_once 'header.php';
?>

<div class="container" id="blankPage">
	<section id="blankHeader">
		<h2>Blank Page</h2>
	</section>
	
</div>

<?php include 'footer.php'; ?>