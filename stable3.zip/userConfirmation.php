<?php 
include 'header.php';
$email = $_GET["email"]
?>

<section id="confimationTable">
	<div id="confirmationTableCell">
		<h3>An activation email as been sent to <?php echo $email; ?></h3>
	</div> 
</section>

</body>

</html>